# Keep config models for Gson
-keep class com.floatingbubble.app.data.** { *; }
