package com.floatingbubble.app.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder

/**
 * Persistance de la configuration en SharedPreferences (JSON).
 */
class ConfigRepository(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val gson: Gson = GsonBuilder().setPrettyPrinting().create()

    fun load(): AppConfig {
        val json = prefs.getString(KEY_CONFIG, null) ?: return AppConfig()
        return try {
            gson.fromJson(json, AppConfig::class.java) ?: AppConfig()
        } catch (_: Exception) {
            AppConfig()
        }
    }

    fun save(config: AppConfig) {
        prefs.edit().putString(KEY_CONFIG, gson.toJson(config)).apply()
    }

    fun exportJson(config: AppConfig): String = gson.toJson(config)

    fun importJson(json: String): AppConfig? {
        return try {
            gson.fromJson(json, AppConfig::class.java)
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        private const val PREFS_NAME = "bubble_config"
        private const val KEY_CONFIG = "config_json"
    }
}
