package com.floatingbubble.app

import android.app.Application
import com.floatingbubble.app.data.ConfigRepository

class BubbleApp : Application() {
    lateinit var configRepository: ConfigRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        configRepository = ConfigRepository(this)
    }

    companion object {
        lateinit var instance: BubbleApp
            private set
    }
}
