package com.floatingbubble.app.data

/**
 * Modèles de configuration de la bulle flottante.
 *
 * Types de petits cercles :
 *  - click  : simule un clic bouton à la position du cercle
 *  - copy   : copie une valeur dans le presse-papiers
 *  - paste  : focus le champ sous le cercle et colle une valeur
 *
 * Type du grand bouton :
 *  - simulate : enchaîne les clics sur les petits cercles
 *  - launcher : exécute une commande / Intent
 */

data class AppConfig(
    var enabled: Boolean = true,
    var timingDetector: Boolean = false,
    var bigButtonType: String = "simulate", // simulate | launcher
    var modes: MutableList<ModeConfig> = mutableListOf(
        ModeConfig(
            name = "Dépôt",
            circles = mutableListOf(
                CircleConfig("Déposer", "click", 0.5f),
                CircleConfig("ID", "paste", 0.8f),
                CircleConfig("Suivant", "click", 0.5f),
                CircleConfig("Montant", "paste", 0.8f),
                CircleConfig("Valider", "click", 1.0f)
            ),
            columns = mutableListOf("ID", "Montant"),
            mapping = mutableMapOf(0 to 1, 1 to 3),
            rows = mutableListOf(
                mutableListOf("128294792", "200 F"),
                mutableListOf("167927826", "500 F")
            )
        ),
        ModeConfig(
            name = "Retrait",
            circles = mutableListOf(
                CircleConfig("Retirer", "click", 0.5f),
                CircleConfig("code", "paste", 0.8f),
                CircleConfig("suivant", "click", 0.5f),
                CircleConfig("montant", "paste", 0.8f),
                CircleConfig("Approuver", "click", 1.0f)
            ),
            columns = mutableListOf("Code", "Numéro"),
            mapping = mutableMapOf(0 to 1, 1 to 3),
            rows = mutableListOf(
                mutableListOf("eh3f", "0194850233"),
                mutableListOf("eh37", "0154811200")
            )
        )
    ),
    var commands: MutableList<LauncherCommand> = mutableListOf()
)

data class ModeConfig(
    var name: String = "Mode",
    var circles: MutableList<CircleConfig> = mutableListOf(),
    /** Noms des colonnes du tableau de ce mode */
    var columns: MutableList<String> = mutableListOf(),
    /** index colonne → index cercle (copy/paste uniquement) */
    var mapping: MutableMap<Int, Int> = mutableMapOf(),
    /** Lignes de données : chaque ligne a autant de cellules que de colonnes */
    var rows: MutableList<MutableList<String>> = mutableListOf(),
    /** Positions sauvegardées des cercles (x, y) en pixels écran */
    var circlePositions: MutableList<Position> = mutableListOf()
)

data class CircleConfig(
    var name: String = "Cercle",
    var type: String = "click", // click | copy | paste
    var delay: Float = 0.5f     // secondes avant le prochain clic
)

data class Position(var x: Float = 100f, var y: Float = 300f)

data class LauncherCommand(
    var value: String = "",
    var mode: String = ""
)

/** État runtime d'une opération en file d'attente */
data class QueueItem(
    val cells: List<String>,
    /** 0=en cours ⭕  1=validé ✅  2=reste à payer ☑️  3=annulé ❌ */
    var status: Int = 0
)

object StatusIcon {
    val ICONS = listOf("⭕", "✅", "☑️", "❌")
    const val IN_PROGRESS = 0
    const val VALIDATED = 1
    const val PENDING_PAY = 2
    const val CANCELLED = 3
}
