package com.floatingbubble.app.data

/**
 * Types de petits cercles :
 *  click        – simule un clic
 *  copy         – copie dans le presse-papiers puis clic
 *  paste        – clic puis colle
 *  click_copy   – clic et copier (sélection / copie zone)
 *  click_paste  – clic et coller
 *  launch_app   – lance une application (packageName)
 *  command      – lance une commande / intent
 *  ussd         – lance un code USSD
 */

data class AppConfig(
    var enabled: Boolean = true,
    var timingDetector: Boolean = false,
    var countdownEnabled: Boolean = true,
    var bigButtonType: String = "simulate",
    var modes: MutableList<ModeConfig> = mutableListOf(
        ModeConfig(
            name = "Dépôt",
            circles = mutableListOf(
                CircleConfig("Déposer", "click", 0.5f),
                CircleConfig("ID", "paste", 0.8f),
                CircleConfig("Suivant", "click", 0.5f),
                CircleConfig("Montant", "paste", 0.8f),
                CircleConfig("Valider", "click", 1.0f)
            ),
            columns = mutableListOf("ID", "Montant"),
            mapping = mutableMapOf(0 to 1, 1 to 3),
            rows = mutableListOf(
                mutableListOf("128294792", "200 F"),
                mutableListOf("167927826", "500 F")
            )
        ),
        ModeConfig(
            name = "Retrait",
            circles = mutableListOf(
                CircleConfig("Retirer", "click", 0.5f),
                CircleConfig("code", "paste", 0.8f),
                CircleConfig("suivant", "click", 0.5f),
                CircleConfig("montant", "paste", 0.8f),
                CircleConfig("Approuver", "click", 1.0f)
            ),
            columns = mutableListOf("Code", "Numéro"),
            mapping = mutableMapOf(0 to 1, 1 to 3),
            rows = mutableListOf(
                mutableListOf("eh3f", "0194850233"),
                mutableListOf("eh37", "0154811200")
            )
        )
    ),
    var commands: MutableList<LauncherCommand> = mutableListOf()
)

data class ModeConfig(
    var name: String = "Mode",
    var circles: MutableList<CircleConfig> = mutableListOf(),
    var columns: MutableList<String> = mutableListOf(),
    var mapping: MutableMap<Int, Int> = mutableMapOf(),
    var rows: MutableList<MutableList<String>> = mutableListOf(),
    var circlePositions: MutableList<Position> = mutableListOf()
)

data class CircleConfig(
    var name: String = "Cercle",
    /** click | copy | paste | click_copy | click_paste | launch_app | command | ussd */
    var type: String = "click",
    var delay: Float = 0.5f,
    /** packageName pour launch_app, commande shell/intent, ou code USSD */
    var payload: String = ""
)

data class Position(var x: Float = 100f, var y: Float = 300f)

data class LauncherCommand(
    var value: String = "",
    var mode: String = ""
)

data class QueueItem(
    val cells: List<String>,
    var status: Int = 0
)

object StatusIcon {
    val ICONS = listOf("⭕", "✅", "☑️", "❌")
    const val IN_PROGRESS = 0
    const val VALIDATED = 1
    const val PENDING_PAY = 2
    const val CANCELLED = 3
}

object CircleTypes {
    val ALL = listOf(
        "click" to "Clic bouton",
        "copy" to "Copier presse-papiers",
        "paste" to "Focus + coller",
        "click_copy" to "Clic et copier",
        "click_paste" to "Clic et coller",
        "launch_app" to "Lancer application",
        "command" to "Lancer commande",
        "ussd" to "Code USSD"
    )
}
