package com.floatingbubble.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.floatingbubble.app.R
import com.floatingbubble.app.service.FloatingBubbleService
import com.floatingbubble.app.util.PermissionHelper
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var statusOverlay: TextView
    private lateinit var statusAccessibility: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusOverlay = findViewById(R.id.statusOverlay)
        statusAccessibility = findViewById(R.id.statusAccessibility)

        findViewById<android.view.View>(R.id.rowOverlay).setOnClickListener {
            if (!PermissionHelper.canDrawOverlays(this)) {
                PermissionHelper.requestOverlayPermission(this)
            }
        }
        findViewById<android.view.View>(R.id.rowAccessibility).setOnClickListener {
            if (!PermissionHelper.isAccessibilityEnabled(this)) {
                PermissionHelper.openAccessibilitySettings(this)
            }
        }

        findViewById<MaterialButton>(R.id.btnStart).setOnClickListener { startBubble() }
        findViewById<MaterialButton>(R.id.btnStop).setOnClickListener {
            FloatingBubbleService.stop(this)
            Toast.makeText(this, "Bulle arrêtée", Toast.LENGTH_SHORT).show()
        }
        findViewById<MaterialButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        refreshPermissionStatus()
    }

    private fun refreshPermissionStatus() {
        statusOverlay.text = if (PermissionHelper.canDrawOverlays(this)) "✅" else "❌"
        statusAccessibility.text = if (PermissionHelper.isAccessibilityEnabled(this)) "✅" else "❌"
    }

    private fun startBubble() {
        if (!PermissionHelper.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.overlay_permission_needed, Toast.LENGTH_LONG).show()
            PermissionHelper.requestOverlayPermission(this)
            return
        }
        if (!PermissionHelper.isAccessibilityEnabled(this)) {
            Toast.makeText(this, R.string.accessibility_permission_needed, Toast.LENGTH_LONG).show()
            PermissionHelper.openAccessibilitySettings(this)
            return
        }
        FloatingBubbleService.start(this)
        Toast.makeText(this, "Bulle démarrée", Toast.LENGTH_SHORT).show()
    }
}
