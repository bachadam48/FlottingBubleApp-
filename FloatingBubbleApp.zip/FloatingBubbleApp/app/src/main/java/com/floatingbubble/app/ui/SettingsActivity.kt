package com.floatingbubble.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.floatingbubble.app.BubbleApp
import com.floatingbubble.app.R
import com.floatingbubble.app.data.AppConfig
import com.floatingbubble.app.data.CircleTypes
import com.floatingbubble.app.service.FloatingBubbleService
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial

class SettingsActivity : AppCompatActivity() {

    private val repo by lazy { BubbleApp.instance.configRepository }
    private lateinit var config: AppConfig

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        findViewById<MaterialToolbar>(R.id.toolbar).apply {
            setNavigationOnClickListener { finish() }
            setNavigationIcon(android.R.drawable.ic_menu_revert)
        }

        config = repo.load()

        val switchEnabled = findViewById<SwitchMaterial>(R.id.switchEnabled)
        val switchTiming = findViewById<SwitchMaterial>(R.id.switchTiming)
        val switchCountdown = findViewById<SwitchMaterial>(R.id.switchCountdown)
        val summary = findViewById<TextView>(R.id.txtModesSummary)

        switchEnabled.isChecked = config.enabled
        switchTiming.isChecked = config.timingDetector
        switchCountdown.isChecked = config.countdownEnabled
        summary.text = buildSummary(config)

        switchEnabled.setOnCheckedChangeListener { _, c -> config.enabled = c }
        switchTiming.setOnCheckedChangeListener { _, c -> config.timingDetector = c }
        switchCountdown.setOnCheckedChangeListener { _, c -> config.countdownEnabled = c }

        findViewById<MaterialButton>(R.id.btnSave).setOnClickListener {
            repo.save(config)
            FloatingBubbleService.reload(this)
            Toast.makeText(this, "Configuration enregistrée", Toast.LENGTH_SHORT).show()
        }

        findViewById<MaterialButton>(R.id.btnExport).setOnClickListener {
            val json = repo.exportJson(config)
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_TEXT, json)
            }, "Exporter"))
        }

        findViewById<MaterialButton>(R.id.btnImport).setOnClickListener {
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            val text = clipboard.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
            if (text.isNullOrBlank()) {
                Toast.makeText(this, "Copiez d'abord un JSON dans le presse-papiers", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val imported = repo.importJson(text)
            if (imported != null) {
                config = imported
                repo.save(config)
                switchEnabled.isChecked = config.enabled
                switchTiming.isChecked = config.timingDetector
                switchCountdown.isChecked = config.countdownEnabled
                summary.text = buildSummary(config)
                FloatingBubbleService.reload(this)
                Toast.makeText(this, "Configuration importée", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "JSON invalide", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun buildSummary(c: AppConfig): String {
        val sb = StringBuilder()
        sb.appendLine("Modes : ${c.modes.size} · Décompte : ${if (c.countdownEnabled) "oui" else "non"}")
        c.modes.forEachIndexed { i, m ->
            sb.appendLine("  ${i + 1}. ${m.name} — ${m.circles.size} cercles, ${m.rows.size} ligne(s)")
            m.circles.forEachIndexed { ci, circle ->
                val typeLabel = CircleTypes.ALL.find { it.first == circle.type }?.second ?: circle.type
                val extra = if (circle.payload.isNotBlank()) " → ${circle.payload.take(20)}" else ""
                sb.appendLine("      ${'A' + ci} ${circle.name} [$typeLabel] ${circle.delay}s$extra")
            }
        }
        return sb.toString()
    }
}
