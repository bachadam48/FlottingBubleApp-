package com.floatingbubble.app.ui

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.floatingbubble.app.BubbleApp
import com.floatingbubble.app.R
import com.floatingbubble.app.data.*
import com.floatingbubble.app.service.FloatingBubbleService
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.switchmaterial.SwitchMaterial

/**
 * Interface de paramétrage complète (alignée sur bubble_settings_ui.html).
 * Modes, cercles, types, délais, mapping, tableaux, options.
 */
class SettingsActivity : AppCompatActivity() {

    private val repo by lazy { BubbleApp.instance.configRepository }
    private lateinit var config: AppConfig
    private lateinit var root: LinearLayout
    private val density by lazy { resources.displayMetrics.density }
    private fun dp(v: Int) = (v * density).toInt()

    private val typeLabels = CircleTypes.ALL.map { it.second }.toTypedArray()
    private val typeValues = CircleTypes.ALL.map { it.first }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        config = repo.load()
        root = findViewById(R.id.settingsRoot)

        findViewById<View>(R.id.btnBackToolbar).setOnClickListener { finish() }
        findViewById<MaterialButton>(R.id.btnSave).setOnClickListener {
            repo.save(config)
            FloatingBubbleService.reload(this)
            Toast.makeText(this, "Configuration enregistrée", Toast.LENGTH_SHORT).show()
        }

        rebuild()
    }

    private fun rebuild() {
        root.removeAllViews()
        addSectionActivation()
        addSectionTiming()
        addSectionModes()
        addSectionBigButton()
        addSectionDataTables()
        addSectionImportExport()
        addSectionGestures()
    }

    // ─── Helpers UI ──────────────────────────────────────

    private fun sectionCard(): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ContextCompat.getColor(this@SettingsActivity, R.color.card))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = dp(10) }
        }
        root.addView(card)
        return card
    }

    private fun title(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text
            setTextColor(ContextCompat.getColor(this@SettingsActivity, R.color.text))
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 0, 0, dp(8))
        })
    }

    private fun hint(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text
            setTextColor(ContextCompat.getColor(this@SettingsActivity, R.color.muted))
            textSize = 11f
            setPadding(0, 0, 0, dp(6))
        })
    }

    private fun switchRow(parent: LinearLayout, label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = dp(6) }
        }
        row.addView(TextView(this).apply {
            this.text = label
            setTextColor(ContextCompat.getColor(this@SettingsActivity, R.color.text))
            textSize = 14f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        val sw = SwitchMaterial(this).apply {
            isChecked = checked
            setOnCheckedChangeListener { _, c -> onChange(c) }
        }
        row.addView(sw)
        parent.addView(row)
    }

    private fun editText(hint: String, value: String, inputType: Int = InputType.TYPE_CLASS_TEXT): EditText {
        return EditText(this).apply {
            setText(value)
            this.hint = hint
            this.inputType = inputType
            setTextColor(ContextCompat.getColor(this@SettingsActivity, R.color.text))
            setHintTextColor(ContextCompat.getColor(this@SettingsActivity, R.color.muted))
            setBackgroundColor(ContextCompat.getColor(this@SettingsActivity, R.color.card2))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            textSize = 13f
        }
    }

    // ─── Sections ────────────────────────────────────────

    private fun addSectionActivation() {
        val c = sectionCard()
        title(c, "1. Activation")
        switchRow(c, "Activer la bulle flottante", config.enabled) { config.enabled = it }
        hint(c, "La bulle reste au-dessus des autres applications.")
    }

    private fun addSectionTiming() {
        val c = sectionCard()
        title(c, "2. Temps & décompte")
        switchRow(c, "Détecteur de temps (1er essai réel)", config.timingDetector) {
            config.timingDetector = it
        }
        hint(c, "Mesure les intervalles entre clics au premier essai et enregistre les délais.")
        switchRow(c, "Activer le décompte entre clics", config.countdownEnabled) {
            config.countdownEnabled = it
        }
        hint(c, "Si désactivé, aucun compte à rebours même si un délai est défini.")
    }

    private fun addSectionModes() {
        val c = sectionCard()
        title(c, "3. Modes & petits cercles")

        // Nombre de modes
        val modesRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(8))
        }
        modesRow.addView(TextView(this).apply {
            text = "Nombre de modes"
            setTextColor(ContextCompat.getColor(this@SettingsActivity, R.color.text))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        val modesCountTv = TextView(this).apply {
            text = config.modes.size.toString()
            setTextColor(ContextCompat.getColor(this@SettingsActivity, R.color.text))
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(12), 0, dp(12), 0)
        }
        modesRow.addView(btn("−") {
            if (config.modes.size > 1) {
                config.modes.removeAt(config.modes.lastIndex)
                rebuild()
            }
        })
        modesRow.addView(modesCountTv)
        modesRow.addView(btn("+") {
            if (config.modes.size < 6) {
                config.modes.add(
                    ModeConfig(
                        name = "Mode ${config.modes.size + 1}",
                        circles = mutableListOf(
                            CircleConfig("Cercle 1", "click", 0.5f),
                            CircleConfig("Cercle 2", "paste", 0.8f)
                        ),
                        columns = mutableListOf("Col1"),
                        mapping = mutableMapOf(0 to 1),
                        rows = mutableListOf(mutableListOf(""))
                    )
                )
                rebuild()
            }
        })
        c.addView(modesRow)
        hint(c, "Chaque mode a son propre nombre de cercles (défini ci-dessous).")

        config.modes.forEachIndexed { mi, mode ->
            addModeCard(c, mi, mode)
        }
    }

    private fun addModeCard(parent: LinearLayout, mi: Int, mode: ModeConfig) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ContextCompat.getColor(this@SettingsActivity, R.color.card2))
            setPadding(dp(10), dp(10), dp(10), dp(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = dp(10) }
        }

        // Nom + stepper cercles
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val nameEt = editText("Nom du mode", mode.name).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnFocusChangeListener { _, has -> if (!has) mode.name = text.toString() }
        }
        head.addView(nameEt)
        head.addView(btn("−") {
            if (mode.circles.size > 1) {
                mode.circles.removeAt(mode.circles.lastIndex)
                rebuild()
            }
        })
        head.addView(TextView(this).apply {
            text = "${mode.circles.size}"
            setTextColor(ContextCompat.getColor(this@SettingsActivity, R.color.text))
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(8), 0, dp(8), 0)
        })
        head.addView(btn("+") {
            if (mode.circles.size < 8) {
                mode.circles.add(CircleConfig("Cercle ${mode.circles.size + 1}", "click", 0.5f))
                rebuild()
            }
        })
        head.addView(TextView(this).apply {
            text = "cercles"
            setTextColor(ContextCompat.getColor(this@SettingsActivity, R.color.muted))
            textSize = 11f
            setPadding(dp(4), 0, 0, 0)
        })
        box.addView(head)

        // En-têtes
        box.addView(TextView(this).apply {
            text = "  #   Nom              Type              Délai  Payload"
            setTextColor(ContextCompat.getColor(this@SettingsActivity, R.color.muted))
            textSize = 10f
            setPadding(0, dp(8), 0, dp(4))
        })

        mode.circles.forEachIndexed { ci, circle ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(4), 0, dp(4))
            }
            val line1 = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            line1.addView(TextView(this).apply {
                text = "${'A' + ci}"
                setTextColor(ContextCompat.getColor(this@SettingsActivity, R.color.text))
                setTypeface(typeface, Typeface.BOLD)
                width = dp(24)
            })
            line1.addView(editText("Nom", circle.name).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnFocusChangeListener { _, has -> if (!has) circle.name = text.toString() }
            })
            // Type spinner
            val spinner = Spinner(this).apply {
                adapter = ArrayAdapter(
                    this@SettingsActivity,
                    android.R.layout.simple_spinner_dropdown_item,
                    typeLabels
                )
                val idx = typeValues.indexOf(circle.type).coerceAtLeast(0)
                setSelection(idx)
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                        circle.type = typeValues[pos]
                    }
                    override fun onNothingSelected(p: AdapterView<*>?) {}
                }
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.2f)
            }
            line1.addView(spinner)
            line1.addView(editText("s", circle.delay.toString(), InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL).apply {
                width = dp(56)
                setOnFocusChangeListener { _, has ->
                    if (!has) circle.delay = text.toString().toFloatOrNull() ?: 0f
                }
            })
            row.addView(line1)

            // Payload (app package / commande / ussd)
            if (circle.type in listOf("launch_app", "command", "ussd", "click_paste")) {
                val payloadRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(24), dp(2), 0, 0)
                }
                payloadRow.addView(editText(
                    when (circle.type) {
                        "launch_app" -> "package de l'app"
                        "ussd" -> "code USSD ex: *123#"
                        else -> "commande / valeur"
                    },
                    circle.payload
                ).apply {
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    setOnFocusChangeListener { _, has -> if (!has) circle.payload = text.toString() }
                })
                if (circle.type == "launch_app") {
                    payloadRow.addView(btn("Apps") { pickInstalledApp { pkg ->
                        circle.payload = pkg
                        rebuild()
                    }})
                }
                row.addView(payloadRow)
            }
            box.addView(row)
        }

        // Mapping colonnes → cercles copy/paste
        val pasteIdx = mode.circles.mapIndexedNotNull { i, c ->
            if (c.type in listOf("copy", "paste", "click_copy", "click_paste")) i else null
        }
        if (pasteIdx.isNotEmpty() && mode.columns.isNotEmpty()) {
            box.addView(TextView(this).apply {
                text = "Mapping colonnes → cercles"
                setTextColor(ContextCompat.getColor(this@SettingsActivity, R.color.teal))
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, dp(8), 0, dp(4))
            })
            mode.columns.forEachIndexed { coli, colName ->
                val mrow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(2), 0, dp(2))
                }
                mrow.addView(TextView(this).apply {
                    text = "« $colName » →"
                    setTextColor(ContextCompat.getColor(this@SettingsActivity, R.color.muted))
                    textSize = 12f
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                })
                val labels = listOf("—") + pasteIdx.map { "${'A' + it} ${mode.circles[it].name}" }
                val values = listOf(-1) + pasteIdx
                val sp = Spinner(this).apply {
                    adapter = ArrayAdapter(this@SettingsActivity, android.R.layout.simple_spinner_dropdown_item, labels)
                    val cur = mode.mapping[coli] ?: -1
                    setSelection(values.indexOf(cur).coerceAtLeast(0))
                    onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                        override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                            val vIdx = values[pos]
                            if (vIdx < 0) mode.mapping.remove(coli) else mode.mapping[coli] = vIdx
                        }
                        override fun onNothingSelected(p: AdapterView<*>?) {}
                    }
                }
                mrow.addView(sp)
                box.addView(mrow)
            }
        }

        parent.addView(box)
    }

    private fun addSectionBigButton() {
        val c = sectionCard()
        title(c, "4. Type du grand bouton")
        val group = RadioGroup(this)
        val r1 = RadioButton(this).apply {
            text = "Simuler un clic sur petit cercle"
            setTextColor(ContextCompat.getColor(this@SettingsActivity, R.color.text))
            id = View.generateViewId()
        }
        val r2 = RadioButton(this).apply {
            text = "Commande launcher"
            setTextColor(ContextCompat.getColor(this@SettingsActivity, R.color.text))
            id = View.generateViewId()
        }
        group.addView(r1)
        group.addView(r2)
        if (config.bigButtonType == "launcher") r2.isChecked = true else r1.isChecked = true
        group.setOnCheckedChangeListener { _, id ->
            config.bigButtonType = if (id == r2.id) "launcher" else "simulate"
        }
        c.addView(group)
    }

    private fun addSectionDataTables() {
        val c = sectionCard()
        title(c, "5. Tableaux de données par mode")
        hint(c, "Chaque mode a son tableau. Colonnes mappées aux cercles Copier / Coller.")

        config.modes.forEachIndexed { mi, mode ->
            c.addView(TextView(this).apply {
                text = "Tableau — ${mode.name}"
                setTextColor(ContextCompat.getColor(this@SettingsActivity, R.color.text))
                setTypeface(typeface, Typeface.BOLD)
                textSize = 13f
                setPadding(0, dp(8), 0, dp(4))
            })

            // Colonnes
            val colRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            mode.columns.forEachIndexed { ci, col ->
                colRow.addView(editText("Col", col).apply {
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                        .also { it.marginEnd = dp(4) }
                    setOnFocusChangeListener { _, has -> if (!has) mode.columns[ci] = text.toString() }
                })
            }
            colRow.addView(btn("+Col") {
                mode.columns.add("Col${mode.columns.size + 1}")
                mode.rows.forEach { it.add("") }
                rebuild()
            })
            if (mode.columns.size > 1) {
                colRow.addView(btn("−Col") {
                    mode.columns.removeAt(mode.columns.lastIndex)
                    mode.rows.forEach { if (it.isNotEmpty()) it.removeAt(it.lastIndex) }
                    rebuild()
                })
            }
            c.addView(colRow)

            // Lignes
            mode.rows.forEachIndexed { ri, row ->
                val r = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, dp(2), 0, dp(2))
                }
                mode.columns.indices.forEach { ci ->
                    r.addView(editText("", row.getOrElse(ci) { "" }).apply {
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                            .also { it.marginEnd = dp(3) }
                        setOnFocusChangeListener { _, has ->
                            if (!has) {
                                while (row.size <= ci) row.add("")
                                row[ci] = text.toString()
                            }
                        }
                    })
                }
                r.addView(btn("✕") {
                    mode.rows.removeAt(ri)
                    rebuild()
                })
                c.addView(r)
            }
            c.addView(btn("＋ Ligne") {
                mode.rows.add(MutableList(mode.columns.size) { "" })
                rebuild()
            })
        }
    }

    private fun addSectionImportExport() {
        val c = sectionCard()
        title(c, "6. Import / Export JSON")
        c.addView(btn("Exporter config JSON") {
            // flush edits by rebuild is not needed; save first
            repo.save(config)
            val json = repo.exportJson(config)
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_TEXT, json)
            }, "Exporter"))
        })
        c.addView(btn("Importer JSON (presse-papiers)") {
            val clip = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            val text = clip.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
            if (text.isNullOrBlank()) {
                Toast.makeText(this, "Copiez un JSON dans le presse-papiers", Toast.LENGTH_LONG).show()
                return@btn
            }
            val imported = repo.importJson(text)
            if (imported != null) {
                config = imported
                repo.save(config)
                FloatingBubbleService.reload(this)
                rebuild()
                Toast.makeText(this, "Importé", Toast.LENGTH_SHORT).show()
            } else Toast.makeText(this, "JSON invalide", Toast.LENGTH_SHORT).show()
        })
    }

    private fun addSectionGestures() {
        val c = sectionCard()
        title(c, "7. Gestes")
        hint(c, "• Appui simple → simuler l'étape (clic réel + animation)\n• Appui long 1,5 s → changer de mode\n• Appui long 2,5 s → fermer la bulle\n• Glisser → déplacer la bulle / les cercles\n• Badge → file d'attente\n• Œil → masquer/afficher les cercles")
    }

    private fun btn(label: String, onClick: () -> Unit): MaterialButton {
        return MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            minimumHeight = dp(36)
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).also { it.marginEnd = dp(4); it.topMargin = dp(4) }
        }
    }

    private fun pickInstalledApp(onPicked: (String) -> Unit) {
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        val labels = apps.map { "${it.loadLabel(pm)} (${it.packageName})" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choisir une application")
            .setItems(labels) { _, which -> onPicked(apps[which].packageName) }
            .setNegativeButton("Annuler", null)
            .show()
    }
}
