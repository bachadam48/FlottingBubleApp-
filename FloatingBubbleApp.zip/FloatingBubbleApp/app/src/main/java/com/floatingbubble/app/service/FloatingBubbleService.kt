package com.floatingbubble.app.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.floatingbubble.app.BubbleApp
import com.floatingbubble.app.R
import com.floatingbubble.app.data.*
import com.floatingbubble.app.ui.MainActivity
import com.floatingbubble.app.util.PermissionHelper
import kotlinx.coroutines.*

/**
 * Service d'overlay affichant la bulle flottante et les petits cercles.
 *
 * Fonctionnalités runtime :
 *  - Appui simple sur la bulle → simule le cercle de l'étape courante
 *  - Appui long 1,5 s → change de mode
 *  - Délais entre clics (décompte affiché, bulle désactivée)
 *  - Détecteur de temps au premier essai
 *  - File d'attente avec statuts ⭕✅☑️❌
 */
class FloatingBubbleService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var circleViews = mutableListOf<View>()
    private var config: AppConfig = AppConfig()

    private var modeIndex = 0
    private var stepIndex = 0
    private var queueIndex = 0
    private var queue = mutableListOf<QueueItem>()
    private var isCountingDown = false
    private var circlesVisible = true
    private var firstRunTiming = true
    private var lastTapTime = 0L
    private val measuredDelays = mutableListOf<Float>()

    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        config = BubbleApp.instance.configRepository.load()
        startForeground(NOTIFICATION_ID, buildNotification())
        initQueue()
        showBubble()
        showCircles()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_RELOAD -> {
                config = BubbleApp.instance.configRepository.load()
                modeIndex = 0
                stepIndex = 0
                initQueue()
                removeCircles()
                showCircles()
                updateBubbleLabel()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        removeBubble()
        removeCircles()
        super.onDestroy()
    }

    // ─── Queue ───────────────────────────────────────────

    private fun initQueue() {
        val mode = currentMode() ?: return
        queue = mode.rows.map { QueueItem(it.toList(), StatusIcon.IN_PROGRESS) }.toMutableList()
        queueIndex = 0
    }

    private fun currentMode(): ModeConfig? =
        config.modes.getOrNull(modeIndex)

    private fun currentCircle(): CircleConfig? =
        currentMode()?.circles?.getOrNull(stepIndex)

    // ─── Overlay helpers ─────────────────────────────────

    private fun overlayParams(x: Int, y: Int, w: Int = WindowManager.LayoutParams.WRAP_CONTENT,
                              h: Int = WindowManager.LayoutParams.WRAP_CONTENT) =
        WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
        }

    // ─── Bubble ──────────────────────────────────────────

    private fun showBubble() {
        if (bubbleView != null) return
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_bubble, null)
        bubbleView = view

        val params = overlayParams(dp(20), dp(200))
        windowManager.addView(view, params)

        val bubbleCore = view.findViewById<View>(R.id.bubbleCore)
        val label = view.findViewById<TextView>(R.id.bubbleLabel)
        val badge = view.findViewById<TextView>(R.id.badge)
        val countdown = view.findViewById<TextView>(R.id.countdownText)

        updateBubbleLabel()
        badge.text = queue.size.toString()

        // Drag
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        var longPressed = false
        val longRunnable = Runnable {
            if (!moved) {
                longPressed = true
                switchMode()
                vibrate(60)
            }
        }

        bubbleCore.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    longPressed = false
                    handler.postDelayed(longRunnable, 1500)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (Math.abs(dx) > 12 || Math.abs(dy) > 12) {
                        moved = true
                        handler.removeCallbacks(longRunnable)
                    }
                    if (moved) {
                        params.x = initialX + dx
                        params.y = initialY + dy
                        windowManager.updateViewLayout(view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longRunnable)
                    if (!moved && !longPressed && !isCountingDown) {
                        performStep()
                    }
                    true
                }
                else -> false
            }
        }

        // Badge → (placeholder: log queue size)
        badge.setOnClickListener {
            // Could show a mini list overlay; for now just refresh
            badge.text = queue.size.toString()
        }
    }

    private fun updateBubbleLabel() {
        val label = bubbleView?.findViewById<TextView>(R.id.bubbleLabel) ?: return
        val circle = currentCircle()
        label.text = circle?.name ?: "—"
        val badge = bubbleView?.findViewById<TextView>(R.id.badge)
        badge?.text = queue.size.toString()
        val core = bubbleView?.findViewById<View>(R.id.bubbleCore)
        core?.setBackgroundResource(
            if (modeIndex % 2 == 0) R.drawable.bg_bubble_amber else R.drawable.bg_bubble_teal
        )
    }

    private fun removeBubble() {
        bubbleView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        bubbleView = null
    }

    // ─── Small circles ───────────────────────────────────

    private fun showCircles() {
        val mode = currentMode() ?: return
        val positions = mode.circlePositions
        mode.circles.forEachIndexed { i, circle ->
            val pos = positions.getOrNull(i) ?: Position(80f + i * 60f, 400f + (i % 3) * 70f)
            addCircleView(i, circle, pos.x, pos.y)
        }
    }

    private fun addCircleView(index: Int, circle: CircleConfig, x: Float, y: Float) {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_circle, null)
        val tv = view.findViewById<TextView>(R.id.circleLabel)
        tv.text = circle.name.take(7)
        val colors = intArrayOf(
            R.drawable.bg_circle_0, R.drawable.bg_circle_1, R.drawable.bg_circle_2,
            R.drawable.bg_circle_3, R.drawable.bg_circle_4, R.drawable.bg_circle_5,
            R.drawable.bg_circle_6, R.drawable.bg_circle_7
        )
        view.findViewById<View>(R.id.circleBg).setBackgroundResource(colors[index % colors.size])

        val params = overlayParams(x.toInt(), y.toInt())
        windowManager.addView(view, params)
        circleViews.add(view)

        // Drag to reposition
        var iX = 0; var iY = 0; var tX = 0f; var tY = 0f
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    iX = params.x; iY = params.y
                    tX = event.rawX; tY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = iX + (event.rawX - tX).toInt()
                    params.y = iY + (event.rawY - tY).toInt()
                    windowManager.updateViewLayout(view, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    // Save position
                    val mode = currentMode()
                    if (mode != null) {
                        while (mode.circlePositions.size <= index) {
                            mode.circlePositions.add(Position())
                        }
                        mode.circlePositions[index] = Position(params.x.toFloat(), params.y.toFloat())
                        BubbleApp.instance.configRepository.save(config)
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun removeCircles() {
        circleViews.forEach {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        circleViews.clear()
    }

    private fun setCirclesVisible(visible: Boolean) {
        circlesVisible = visible
        circleViews.forEach { it.visibility = if (visible) View.VISIBLE else View.GONE }
    }

    // ─── Step execution ──────────────────────────────────

    private fun performStep() {
        val mode = currentMode() ?: return
        val circle = currentCircle() ?: return
        val service = ClickAccessibilityService.instance

        // Timing detector (premier essai)
        if (config.timingDetector && firstRunTiming) {
            val now = SystemClock.elapsedRealtime()
            if (lastTapTime > 0) {
                val delaySec = (now - lastTapTime) / 1000f
                measuredDelays.add(delaySec)
                if (stepIndex < mode.circles.size) {
                    mode.circles[stepIndex].delay = delaySec
                }
            }
            lastTapTime = now
        }

        val pos = mode.circlePositions.getOrNull(stepIndex)
        val cx = pos?.x ?: 200f
        val cy = pos?.y ?: 400f
        // Center of circle (~38dp)
        val tapX = cx + dp(19)
        val tapY = cy + dp(19)

        when (circle.type) {
            "click" -> service?.tap(tapX.toFloat(), tapY.toFloat())
            "copy" -> {
                val value = mappedValueForCircle(stepIndex)
                if (value != null) {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("bubble", value))
                }
                service?.tap(tapX.toFloat(), tapY.toFloat())
            }
            "paste" -> {
                val value = mappedValueForCircle(stepIndex)
                service?.tap(tapX.toFloat(), tapY.toFloat())
                if (value != null) {
                    handler.postDelayed({ service?.pasteText(value) }, 120)
                }
            }
        }

        vibrate(30)

        // Fin d'étape spéciale
        val isLast = stepIndex >= mode.circles.size - 1
        val name = circle.name.lowercase()
        if (isLast || name.contains("valider")) {
            markQueueItem(StatusIcon.VALIDATED)
        } else if (name.contains("approuver")) {
            markQueueItem(StatusIcon.PENDING_PAY)
        }

        // Avancer
        stepIndex++
        if (stepIndex >= mode.circles.size) {
            stepIndex = 0
            advanceQueue()
        }

        updateBubbleLabel()

        // Délai avant prochain clic
        val delay = (circle.delay * 1000).toLong().coerceAtLeast(0)
        if (delay > 0) {
            startCountdown(delay)
        }
    }

    private fun mappedValueForCircle(circleIdx: Int): String? {
        val mode = currentMode() ?: return null
        val item = queue.getOrNull(queueIndex) ?: return null
        // mapping: columnIndex → circleIndex
        val entry = mode.mapping.entries.find { it.value == circleIdx } ?: return null
        val colIdx = entry.key
        return item.cells.getOrNull(colIdx)
    }

    private fun markQueueItem(status: Int) {
        queue.getOrNull(queueIndex)?.status = status
        // Supprimer après 2s si terminé
        if (status == StatusIcon.VALIDATED || status == StatusIcon.CANCELLED) {
            val idx = queueIndex
            handler.postDelayed({
                if (idx < queue.size) {
                    queue.removeAt(idx)
                    if (queueIndex >= queue.size) queueIndex = 0
                    updateBubbleLabel()
                    if (queue.isEmpty()) hideAllExceptBubble()
                }
            }, 2000)
        }
    }

    private fun advanceQueue() {
        // Passer au prochain item non terminé
        if (queue.isEmpty()) return
        var next = (queueIndex + 1) % queue.size
        var tries = 0
        while (tries < queue.size) {
            val s = queue[next].status
            if (s != StatusIcon.VALIDATED && s != StatusIcon.CANCELLED) {
                queueIndex = next
                return
            }
            next = (next + 1) % queue.size
            tries++
        }
    }

    private fun hideAllExceptBubble() {
        removeCircles()
        // Side buttons would be hidden here if present
    }

    private fun switchMode() {
        if (config.modes.isEmpty()) return
        modeIndex = (modeIndex + 1) % config.modes.size
        stepIndex = 0
        initQueue()
        removeCircles()
        showCircles()
        updateBubbleLabel()

        // Sauvegarder délais mesurés si détecteur actif
        if (config.timingDetector && measuredDelays.isNotEmpty()) {
            firstRunTiming = false
            BubbleApp.instance.configRepository.save(config)
            measuredDelays.clear()
        }
    }

    // ─── Countdown ───────────────────────────────────────

    private fun startCountdown(totalMs: Long) {
        isCountingDown = true
        val countdownTv = bubbleView?.findViewById<TextView>(R.id.countdownText)
        countdownTv?.visibility = View.VISIBLE
        val start = SystemClock.elapsedRealtime()

        fun tick() {
            val elapsed = SystemClock.elapsedRealtime() - start
            val remaining = totalMs - elapsed
            if (remaining <= 0) {
                isCountingDown = false
                countdownTv?.visibility = View.GONE
                countdownTv?.text = ""
                return
            }
            val sec = remaining / 1000f
            countdownTv?.text = String.format("%.1f", sec)
            handler.postDelayed({ tick() }, 50)
        }
        tick()
    }

    // ─── Utils ───────────────────────────────────────────

    private fun vibrate(ms: Long) {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            v.vibrate(ms)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildNotification(): Notification {
        val channelId = "bubble_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                getString(R.string.notification_channel),
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.floatingbubble.app.STOP"
        const val ACTION_RELOAD = "com.floatingbubble.app.RELOAD"
        private const val NOTIFICATION_ID = 42

        fun start(context: Context) {
            val intent = Intent(context, FloatingBubbleService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.startService(
                Intent(context, FloatingBubbleService::class.java).setAction(ACTION_STOP)
            )
        }

        fun reload(context: Context) {
            context.startService(
                Intent(context, FloatingBubbleService::class.java).setAction(ACTION_RELOAD)
            )
        }
    }
}
