package com.floatingbubble.app.service

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.*
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.floatingbubble.app.BubbleApp
import com.floatingbubble.app.R
import com.floatingbubble.app.data.*
import com.floatingbubble.app.ui.MainActivity

/**
 * Overlay flottant — design mockup HTML.
 *
 * Ordre d'exécution : 1) clic réel  2) animation ripple  3) décompte si délai > 0
 * Fonctionne même sans tableau de données (simulation pure des cercles).
 */
class FloatingBubbleService : Service() {

    private lateinit var windowManager: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var config: AppConfig = AppConfig()

    private var groupView: View? = null
    private var groupParams: WindowManager.LayoutParams? = null
    private val circleViews = mutableListOf<View>()
    private val circleParams = mutableListOf<WindowManager.LayoutParams>()

    private var modeIndex = 0
    private var stepIndex = 0
    private var queueIndex = 0
    private var queue = mutableListOf<QueueItem>()
    private var isCountingDown = false
    private var circlesVisible = true
    private var listVisible = false
    private var firstRunTiming = true
    private var lastTapTime = 0L

    private var bubbleLabel: TextView? = null
    private var bubbleCore: View? = null
    private var badge: TextView? = null
    private var eyeBtn: TextView? = null
    private var countdownText: TextView? = null
    private var btnNext: TextView? = null
    private var btnCancel: TextView? = null
    private var btnBack: TextView? = null
    private var opsList: View? = null
    private var opsListTitle: TextView? = null
    private var opsListBody: LinearLayout? = null
    private var topIcons: View? = null
    private var mainBubble: View? = null

    private val circleColors = intArrayOf(
        R.drawable.bg_circle_0, R.drawable.bg_circle_1, R.drawable.bg_circle_2,
        R.drawable.bg_circle_3, R.drawable.bg_circle_4, R.drawable.bg_circle_5,
        R.drawable.bg_circle_6, R.drawable.bg_circle_7
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        config = BubbleApp.instance.configRepository.load()
        startForeground(NOTIFICATION_ID, buildNotification())
        initQueue()
        showGroup()
        showCircles()
        updateUI()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_RELOAD -> {
                config = BubbleApp.instance.configRepository.load()
                modeIndex = 0; stepIndex = 0
                initQueue()
                removeCircles(); showCircles()
                updateUI()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        removeCircles()
        removeGroup()
        super.onDestroy()
    }

    // ─── Queue (optionnelle) ─────────────────────────────

    private fun initQueue() {
        val mode = currentMode()
        queue = if (mode != null && mode.rows.isNotEmpty()) {
            mode.rows.map { QueueItem(it.toList(), StatusIcon.IN_PROGRESS) }.toMutableList()
        } else {
            mutableListOf() // pas de tableau → file vide, les clics marchent quand même
        }
        queueIndex = 0
    }

    private fun currentMode(): ModeConfig? = config.modes.getOrNull(modeIndex)
    private fun currentCircle(): CircleConfig? = currentMode()?.circles?.getOrNull(stepIndex)
    private fun hasQueue(): Boolean = queue.isNotEmpty()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun baseParams(x: Int, y: Int, w: Int = WindowManager.LayoutParams.WRAP_CONTENT,
                           h: Int = WindowManager.LayoutParams.WRAP_CONTENT) =
        WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
        }

    // ─── Groupe ──────────────────────────────────────────

    private fun showGroup() {
        if (groupView != null) return
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_bubble_group, null)
        groupView = view

        bubbleLabel = view.findViewById(R.id.bubbleLabel)
        bubbleCore = view.findViewById(R.id.bubbleCore)
        badge = view.findViewById(R.id.badge)
        eyeBtn = view.findViewById(R.id.eyeBtn)
        countdownText = view.findViewById(R.id.countdownText)
        btnNext = view.findViewById(R.id.btnNext)
        btnCancel = view.findViewById(R.id.btnCancel)
        btnBack = view.findViewById(R.id.btnBack)
        opsList = view.findViewById(R.id.opsList)
        opsListTitle = view.findViewById(R.id.opsListTitle)
        opsListBody = view.findViewById(R.id.opsListBody)
        topIcons = view.findViewById(R.id.topIcons)
        mainBubble = view.findViewById(R.id.mainBubble)

        val dm = resources.displayMetrics
        val params = baseParams(dm.widthPixels - dp(160), dm.heightPixels - dp(240))
        groupParams = params
        windowManager.addView(view, params)

        setupGroupDragAndTap()
        setupButtons()
    }

    private fun setupGroupDragAndTap() {
        val bubble = mainBubble ?: return
        val params = groupParams ?: return
        var iX = 0; var iY = 0; var tX = 0f; var tY = 0f
        var moved = false; var longFired = false
        val longRunnable = Runnable {
            if (!moved) {
                longFired = true
                switchMode()
                vibrate(60)
            }
        }

        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    iX = params.x; iY = params.y
                    tX = e.rawX; tY = e.rawY
                    moved = false; longFired = false
                    handler.postDelayed(longRunnable, 1500)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tX).toInt()
                    val dy = (e.rawY - tY).toInt()
                    if (kotlin.math.abs(dx) > 12 || kotlin.math.abs(dy) > 12) {
                        moved = true
                        handler.removeCallbacks(longRunnable)
                    }
                    if (moved) {
                        params.x = iX + dx
                        params.y = iY + dy
                        try { windowManager.updateViewLayout(groupView, params) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longRunnable)
                    // Appui simple : clic d'abord (même pendant un décompte on ignore)
                    if (!moved && !longFired && !isCountingDown) {
                        performStep()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun setupButtons() {
        btnNext?.setOnClickListener {
            if (!hasQueue()) return@setOnClickListener
            val next = findNextActiveIndex(queueIndex)
            if (next >= 0) {
                queueIndex = next
                stepIndex = 0
                updateUI()
                vibrate(25)
            }
        }

        btnCancel?.setOnClickListener {
            if (!hasQueue()) return@setOnClickListener
            val item = queue.getOrNull(queueIndex) ?: return@setOnClickListener
            val processed = queueIndex
            if (item.status == StatusIcon.PENDING_PAY) {
                item.status = StatusIcon.VALIDATED
            } else {
                item.status = StatusIcon.CANCELLED
            }
            scheduleRemove(processed)
            autoAdvance()
            vibrate(40)
            updateUI()
        }

        btnBack?.setOnClickListener {
            val mode = currentMode() ?: return@setOnClickListener
            if (mode.circles.isEmpty()) return@setOnClickListener
            stepIndex = (stepIndex - 1 + mode.circles.size) % mode.circles.size
            updateUI()
        }

        eyeBtn?.setOnClickListener {
            circlesVisible = !circlesVisible
            circleViews.forEach {
                it.visibility = if (circlesVisible) View.VISIBLE else View.GONE
            }
            eyeBtn?.text = if (circlesVisible) "👁" else "👁‍🗨"
        }

        badge?.setOnClickListener {
            if (!hasQueue()) return@setOnClickListener
            listVisible = !listVisible
            opsList?.visibility = if (listVisible) View.VISIBLE else View.GONE
            if (listVisible) renderOpsList()
        }
    }

    private fun removeGroup() {
        groupView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        groupView = null
    }

    // ─── Cercles 38dp ────────────────────────────────────

    private fun showCircles() {
        val mode = currentMode() ?: return
        val dm = resources.displayMetrics
        mode.circles.forEachIndexed { i, circle ->
            val saved = mode.circlePositions.getOrNull(i)
            val x = saved?.x?.toInt() ?: (dp(24) + (i % 3) * dp(50))
            val y = saved?.y?.toInt() ?: (dm.heightPixels / 3 + (i / 3) * dp(50))
            addCircle(i, circle, x, y)
        }
    }

    private fun addCircle(index: Int, circle: CircleConfig, x: Int, y: Int) {
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_circle, null)
        val size = dp(38)
        view.layoutParams = ViewGroup.LayoutParams(size, size)

        view.findViewById<View>(R.id.circleBg)
            .setBackgroundResource(circleColors[index % circleColors.size])
        view.findViewById<TextView>(R.id.circleLabel).text =
            circle.name.let { if (it.length > 7) it.take(6) + "…" else it }

        val params = baseParams(x, y, size, size)
        windowManager.addView(view, params)
        circleViews.add(view)
        circleParams.add(params)

        var iX = 0; var iY = 0; var tX = 0f; var tY = 0f
        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    iX = params.x; iY = params.y
                    tX = e.rawX; tY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = iX + (e.rawX - tX).toInt()
                    params.y = iY + (e.rawY - tY).toInt()
                    try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val mode = currentMode()
                    if (mode != null) {
                        while (mode.circlePositions.size <= index) mode.circlePositions.add(Position())
                        mode.circlePositions[index] = Position(params.x.toFloat(), params.y.toFloat())
                        BubbleApp.instance.configRepository.save(config)
                    }
                    true
                }
                else -> false
            }
        }
        if (!circlesVisible) view.visibility = View.GONE
    }

    private fun removeCircles() {
        circleViews.forEach { try { windowManager.removeView(it) } catch (_: Exception) {} }
        circleViews.clear()
        circleParams.clear()
    }

    // ─── Animation ripple sur zone cliquée ───────────────

    private fun showRipple(screenX: Float, screenY: Float) {
        val size = dp(48)
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_ripple, null)
        val params = baseParams(
            (screenX - size / 2f).toInt(),
            (screenY - size / 2f).toInt(),
            size, size
        )
        // Le ripple doit laisser passer les touchs
        params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try {
            windowManager.addView(view, params)
        } catch (_: Exception) {
            return
        }

        view.alpha = 0.9f
        view.scaleX = 0.3f
        view.scaleY = 0.3f

        val anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 420
            interpolator = DecelerateInterpolator()
            addUpdateListener { a ->
                val t = a.animatedFraction
                view.scaleX = 0.3f + t * 1.7f
                view.scaleY = 0.3f + t * 1.7f
                view.alpha = 0.9f * (1f - t)
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    try { windowManager.removeView(view) } catch (_: Exception) {}
                }
            })
        }
        anim.start()

        // Pulse sur le petit cercle correspondant
        circleViews.getOrNull(stepIndex)?.let { cv ->
            cv.animate().scaleX(1.25f).scaleY(1.25f).setDuration(150)
                .withEndAction {
                    cv.animate().scaleX(1f).scaleY(1f).setDuration(150).start()
                }.start()
        }
    }

    // ─── UI ──────────────────────────────────────────────

    private fun updateUI() {
        val mode = currentMode()
        val circle = currentCircle()
        bubbleLabel?.text = circle?.name ?: "—"
        badge?.text = queue.size.toString()

        bubbleCore?.setBackgroundResource(
            if (modeIndex % 2 == 0) R.drawable.bg_bubble_amber else R.drawable.bg_bubble_teal
        )

        val item = queue.getOrNull(queueIndex)
        when {
            item?.status == StatusIcon.PENDING_PAY -> {
                btnCancel?.text = "PAYER"
                btnCancel?.setBackgroundResource(R.drawable.bg_side_pay)
            }
            modeIndex % 2 == 0 -> {
                btnCancel?.text = "ANNULER"
                btnCancel?.setBackgroundResource(R.drawable.bg_side_cancel)
            }
            else -> {
                btnCancel?.text = "ERREUR"
                btnCancel?.setBackgroundResource(R.drawable.bg_side_cancel)
            }
        }

        // Sans file : masquer badge/liste/boutons file, garder bulle + cercles + œil + retour
        val empty = !hasQueue()
        btnNext?.visibility = if (empty) View.GONE else View.VISIBLE
        btnCancel?.visibility = if (empty) View.GONE else View.VISIBLE
        badge?.visibility = if (empty) View.INVISIBLE else View.VISIBLE
        if (empty) {
            opsList?.visibility = View.GONE
            listVisible = false
        }

        if (listVisible) renderOpsList()
    }

    private fun renderOpsList() {
        val body = opsListBody ?: return
        body.removeAllViews()
        val mode = currentMode()
        opsListTitle?.text = if (mode != null) "File ${mode.name} (${queue.size})" else "File"

        queue.forEachIndexed { i, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(4), dp(3), dp(4), dp(3))
                setBackgroundResource(
                    if (i == queueIndex) R.drawable.bg_ops_item_current else R.drawable.bg_ops_item
                )
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.bottomMargin = dp(2) }
            }
            fun tv(text: String, weight: Float, size: Float, color: Int, gravity: Int = Gravity.START) =
                TextView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, weight)
                    this.text = text
                    textSize = size
                    setTextColor(color)
                    this.gravity = gravity
                    maxLines = 1
                }
            val c = if (i == queueIndex) 0xFFFDE68A.toInt() else 0xFFCBD5E1.toInt()
            row.addView(tv(item.cells.getOrNull(0) ?: "", 1f, 9f, c))
            row.addView(tv(StatusIcon.ICONS.getOrElse(item.status) { "⭕" }, 0.3f, 11f, c, Gravity.CENTER))
            row.addView(tv(
                item.cells.getOrNull(1) ?: item.cells.lastOrNull() ?: "",
                1f, 8f, if (i == queueIndex) 0xFFFDE68A.toInt() else 0xFF94A3B8.toInt(), Gravity.END
            ))
            body.addView(row)
        }
    }

    // ─── Exécution étape : CLIC d'abord, puis décompte ────

    private fun performStep() {
        val mode = currentMode() ?: return
        if (mode.circles.isEmpty()) return
        val circle = currentCircle() ?: return
        val service = ClickAccessibilityService.instance

        // Détecteur de temps (mesure entre clics réels)
        if (config.timingDetector && firstRunTiming) {
            val now = SystemClock.elapsedRealtime()
            if (lastTapTime > 0) {
                val measured = ((now - lastTapTime) / 1000f).coerceIn(0f, 30f)
                if (stepIndex < mode.circles.size) {
                    mode.circles[stepIndex].delay = measured
                }
            }
            lastTapTime = now
        }

        // Position du cercle cible
        val params = circleParams.getOrNull(stepIndex)
        val size = dp(38)
        val tapX = (params?.x ?: 200) + size / 2f
        val tapY = (params?.y ?: 400) + size / 2f

        // 1) CLIC RÉEL (accessibilité) + copy/paste si configuré
        when (circle.type) {
            "click" -> {
                service?.tap(tapX, tapY)
            }
            "copy" -> {
                mappedValue(stepIndex)?.let { v ->
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("bubble", v))
                }
                service?.tap(tapX, tapY)
            }
            "paste" -> {
                val v = mappedValue(stepIndex)
                service?.tap(tapX, tapY)
                if (v != null) {
                    handler.postDelayed({ service?.pasteText(v) }, 150)
                }
            }
            else -> service?.tap(tapX, tapY)
        }

        // 2) Animation ripple sur la zone cliquée
        showRipple(tapX, tapY)
        vibrate(30)

        // 3) Mise à jour file si présente
        val name = circle.name.lowercase()
        val isLast = stepIndex >= mode.circles.size - 1
        if (hasQueue()) {
            if (isLast || name.contains("valider")) {
                markItem(StatusIcon.VALIDATED)
            } else if (name.contains("approuver")) {
                markItem(StatusIcon.PENDING_PAY)
            }
        }

        // Avancer l'étape
        val delaySec = circle.delay
        stepIndex++
        if (stepIndex >= mode.circles.size) {
            stepIndex = 0
            if (hasQueue() && !name.contains("approuver")) autoAdvance()
            if (config.timingDetector && firstRunTiming) {
                firstRunTiming = false
                BubbleApp.instance.configRepository.save(config)
            }
        }
        updateUI()

        // 4) Décompte SEULEMENT si délai défini et > 0
        if (delaySec > 0f) {
            startCountdown((delaySec * 1000).toLong())
        }
    }

    private fun mappedValue(circleIdx: Int): String? {
        if (!hasQueue()) return null
        val mode = currentMode() ?: return null
        val item = queue.getOrNull(queueIndex) ?: return null
        val col = mode.mapping.entries.find { it.value == circleIdx }?.key ?: return null
        return item.cells.getOrNull(col)
    }

    private fun markItem(status: Int) {
        queue.getOrNull(queueIndex)?.status = status
        if (status == StatusIcon.VALIDATED || status == StatusIcon.CANCELLED) {
            scheduleRemove(queueIndex)
        }
    }

    private fun scheduleRemove(idx: Int) {
        handler.postDelayed({
            if (idx in queue.indices) {
                queue.removeAt(idx)
                if (queueIndex >= queue.size) queueIndex = maxOf(0, queue.size - 1)
                if (queueIndex < 0) queueIndex = 0
                stepIndex = 0
                updateUI()
            }
        }, 2000)
    }

    private fun findNextActiveIndex(from: Int): Int {
        if (queue.isEmpty()) return -1
        for (i in 1..queue.size) {
            val idx = (from + i) % queue.size
            val s = queue[idx].status
            if (s != StatusIcon.VALIDATED && s != StatusIcon.CANCELLED) return idx
        }
        return -1
    }

    private fun autoAdvance() {
        val next = findNextActiveIndex(queueIndex)
        if (next >= 0) queueIndex = next
        stepIndex = 0
        updateUI()
    }

    private fun switchMode() {
        if (config.modes.isEmpty()) return
        modeIndex = (modeIndex + 1) % config.modes.size
        stepIndex = 0
        initQueue()
        removeCircles()
        showCircles()
        updateUI()
    }

    /** Décompte après le clic — uniquement si délai > 0 */
    private fun startCountdown(ms: Long) {
        if (ms <= 0L) return
        isCountingDown = true
        countdownText?.visibility = View.VISIBLE
        val start = SystemClock.elapsedRealtime()
        fun tick() {
            val left = ms - (SystemClock.elapsedRealtime() - start)
            if (left <= 0) {
                isCountingDown = false
                countdownText?.visibility = View.GONE
                countdownText?.text = ""
                return
            }
            countdownText?.text = String.format("%.1f", left / 1000f)
            handler.postDelayed({ tick() }, 50)
        }
        tick()
    }

    private fun vibrate(ms: Long) {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION") v.vibrate(ms)
        }
    }

    private fun buildNotification(): Notification {
        val channelId = "bubble_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                channelId, getString(R.string.notification_channel),
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(ch)
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.floatingbubble.app.STOP"
        const val ACTION_RELOAD = "com.floatingbubble.app.RELOAD"
        private const val NOTIFICATION_ID = 42

        fun start(ctx: Context) {
            val i = Intent(ctx, FloatingBubbleService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(i)
            else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, FloatingBubbleService::class.java).setAction(ACTION_STOP))
        }

        fun reload(ctx: Context) {
            ctx.startService(Intent(ctx, FloatingBubbleService::class.java).setAction(ACTION_RELOAD))
        }
    }
}
