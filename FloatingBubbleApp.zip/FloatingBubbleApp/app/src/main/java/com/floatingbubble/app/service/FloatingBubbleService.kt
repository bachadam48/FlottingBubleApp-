package com.floatingbubble.app.service

import android.app.*
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.floatingbubble.app.BubbleApp
import com.floatingbubble.app.R
import com.floatingbubble.app.data.*
import com.floatingbubble.app.ui.MainActivity
import kotlinx.coroutines.*

/**
 * Overlay flottant aligné sur le mockup HTML :
 * - Groupe : [SUIVANT] [œil+badge+bulle+retour] [ANNULER/ERREUR/PAYER]
 * - Petits cercles 38dp, draggables, un set par mode
 * - Appui simple → simule l'étape courante
 * - Appui long 1,5s → change de mode
 * - Délais avec décompte, file d'attente, mapping copy/paste
 */
class FloatingBubbleService : Service() {

    private lateinit var windowManager: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var config: AppConfig = AppConfig()

    private var groupView: View? = null
    private var groupParams: WindowManager.LayoutParams? = null
    private val circleViews = mutableListOf<View>()
    private val circleParams = mutableListOf<WindowManager.LayoutParams>()

    private var modeIndex = 0
    private var stepIndex = 0
    private var queueIndex = 0
    private var queue = mutableListOf<QueueItem>()
    private var isCountingDown = false
    private var circlesVisible = true
    private var listVisible = false
    private var firstRunTiming = true
    private var lastTapTime = 0L

    // Views du groupe
    private var bubbleLabel: TextView? = null
    private var bubbleCore: View? = null
    private var badge: TextView? = null
    private var eyeBtn: TextView? = null
    private var countdownText: TextView? = null
    private var btnNext: TextView? = null
    private var btnCancel: TextView? = null
    private var btnBack: TextView? = null
    private var opsList: View? = null
    private var opsListTitle: TextView? = null
    private var opsListBody: LinearLayout? = null
    private var topIcons: View? = null
    private var mainBubble: View? = null

    private val circleColors = intArrayOf(
        R.drawable.bg_circle_0, R.drawable.bg_circle_1, R.drawable.bg_circle_2,
        R.drawable.bg_circle_3, R.drawable.bg_circle_4, R.drawable.bg_circle_5,
        R.drawable.bg_circle_6, R.drawable.bg_circle_7
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        config = BubbleApp.instance.configRepository.load()
        startForeground(NOTIFICATION_ID, buildNotification())
        initQueue()
        showGroup()
        showCircles()
        updateUI()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_RELOAD -> {
                config = BubbleApp.instance.configRepository.load()
                modeIndex = 0; stepIndex = 0
                initQueue()
                removeCircles(); showCircles()
                updateUI()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        removeCircles()
        removeGroup()
        super.onDestroy()
    }

    // ─── Queue ───────────────────────────────────────────

    private fun initQueue() {
        val mode = currentMode() ?: return
        queue = mode.rows.map { QueueItem(it.toList(), StatusIcon.IN_PROGRESS) }.toMutableList()
        queueIndex = 0
    }

    private fun currentMode(): ModeConfig? = config.modes.getOrNull(modeIndex)
    private fun currentCircle(): CircleConfig? = currentMode()?.circles?.getOrNull(stepIndex)

    // ─── Window params ───────────────────────────────────

    private fun baseParams(x: Int, y: Int): WindowManager.LayoutParams {
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
            // Important : ne PAS utiliser MATCH_PARENT
            width = WindowManager.LayoutParams.WRAP_CONTENT
            height = WindowManager.LayoutParams.WRAP_CONTENT
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ─── Groupe flottant ─────────────────────────────────

    private fun showGroup() {
        if (groupView != null) return
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_bubble_group, null)
        groupView = view

        bubbleLabel = view.findViewById(R.id.bubbleLabel)
        bubbleCore = view.findViewById(R.id.bubbleCore)
        badge = view.findViewById(R.id.badge)
        eyeBtn = view.findViewById(R.id.eyeBtn)
        countdownText = view.findViewById(R.id.countdownText)
        btnNext = view.findViewById(R.id.btnNext)
        btnCancel = view.findViewById(R.id.btnCancel)
        btnBack = view.findViewById(R.id.btnBack)
        opsList = view.findViewById(R.id.opsList)
        opsListTitle = view.findViewById(R.id.opsListTitle)
        opsListBody = view.findViewById(R.id.opsListBody)
        topIcons = view.findViewById(R.id.topIcons)
        mainBubble = view.findViewById(R.id.mainBubble)

        // Position initiale bas-droite approximative
        val dm = resources.displayMetrics
        val params = baseParams(dm.widthPixels - dp(160), dm.heightPixels - dp(220))
        groupParams = params
        windowManager.addView(view, params)

        setupGroupDragAndTap()
        setupButtons()
    }

    private fun setupGroupDragAndTap() {
        val bubble = mainBubble ?: return
        val params = groupParams ?: return
        var iX = 0; var iY = 0; var tX = 0f; var tY = 0f
        var moved = false; var longFired = false
        val longRunnable = Runnable {
            if (!moved) {
                longFired = true
                switchMode()
                vibrate(60)
            }
        }

        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    iX = params.x; iY = params.y
                    tX = e.rawX; tY = e.rawY
                    moved = false; longFired = false
                    handler.postDelayed(longRunnable, 1500)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tX).toInt()
                    val dy = (e.rawY - tY).toInt()
                    if (kotlin.math.abs(dx) > 12 || kotlin.math.abs(dy) > 12) {
                        moved = true
                        handler.removeCallbacks(longRunnable)
                    }
                    if (moved) {
                        params.x = iX + dx
                        params.y = iY + dy
                        try { windowManager.updateViewLayout(groupView, params) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longRunnable)
                    if (!moved && !longFired && !isCountingDown) {
                        performStep()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun setupButtons() {
        btnNext?.setOnClickListener {
            val next = findNextActiveIndex(queueIndex)
            if (next >= 0) {
                queueIndex = next
                stepIndex = 0
                updateUI()
                vibrate(25)
            }
        }

        btnCancel?.setOnClickListener {
            if (queue.isEmpty()) return@setOnClickListener
            val item = queue.getOrNull(queueIndex) ?: return@setOnClickListener
            val processed = queueIndex
            if (item.status == StatusIcon.PENDING_PAY) {
                item.status = StatusIcon.VALIDATED
                scheduleRemove(processed)
                autoAdvance()
            } else {
                item.status = StatusIcon.CANCELLED
                scheduleRemove(processed)
                autoAdvance()
            }
            vibrate(40)
            updateUI()
        }

        btnBack?.setOnClickListener {
            val mode = currentMode() ?: return@setOnClickListener
            stepIndex = (stepIndex - 1 + mode.circles.size) % mode.circles.size
            updateUI()
        }

        eyeBtn?.setOnClickListener {
            circlesVisible = !circlesVisible
            circleViews.forEach {
                it.visibility = if (circlesVisible) View.VISIBLE else View.GONE
            }
            eyeBtn?.text = if (circlesVisible) "👁" else "👁‍🗨"
            eyeBtn?.setBackgroundResource(
                if (circlesVisible) R.drawable.bg_eye else R.drawable.bg_side_pay
            )
        }

        badge?.setOnClickListener {
            listVisible = !listVisible
            opsList?.visibility = if (listVisible) View.VISIBLE else View.GONE
            if (listVisible) renderOpsList()
        }
    }

    private fun removeGroup() {
        groupView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        groupView = null
    }

    // ─── Petits cercles 38dp ─────────────────────────────

    private fun showCircles() {
        val mode = currentMode() ?: return
        val dm = resources.displayMetrics
        mode.circles.forEachIndexed { i, circle ->
            val saved = mode.circlePositions.getOrNull(i)
            val x = saved?.x?.toInt() ?: (dp(24) + (i % 3) * dp(50))
            val y = saved?.y?.toInt() ?: (dm.heightPixels / 3 + (i / 3) * dp(50))
            addCircle(i, circle, x, y)
        }
    }

    private fun addCircle(index: Int, circle: CircleConfig, x: Int, y: Int) {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_circle, null)

        // Forcer taille 38dp
        val size = dp(38)
        view.layoutParams = ViewGroup.LayoutParams(size, size)

        val bg = view.findViewById<View>(R.id.circleBg)
        bg.setBackgroundResource(circleColors[index % circleColors.size])
        val label = view.findViewById<TextView>(R.id.circleLabel)
        label.text = circle.name.let { if (it.length > 7) it.take(6) + "…" else it }

        val params = baseParams(x, y).apply {
            width = size
            height = size
        }

        windowManager.addView(view, params)
        circleViews.add(view)
        circleParams.add(params)

        // Drag individuel
        var iX = 0; var iY = 0; var tX = 0f; var tY = 0f
        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    iX = params.x; iY = params.y
                    tX = e.rawX; tY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = iX + (e.rawX - tX).toInt()
                    params.y = iY + (e.rawY - tY).toInt()
                    try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val mode = currentMode()
                    if (mode != null) {
                        while (mode.circlePositions.size <= index) {
                            mode.circlePositions.add(Position())
                        }
                        mode.circlePositions[index] = Position(params.x.toFloat(), params.y.toFloat())
                        BubbleApp.instance.configRepository.save(config)
                    }
                    true
                }
                else -> false
            }
        }

        if (!circlesVisible) view.visibility = View.GONE
    }

    private fun removeCircles() {
        circleViews.forEach { try { windowManager.removeView(it) } catch (_: Exception) {} }
        circleViews.clear()
        circleParams.clear()
    }

    // ─── UI update ───────────────────────────────────────

    private fun updateUI() {
        val mode = currentMode()
        val circle = currentCircle()
        bubbleLabel?.text = circle?.name ?: "—"
        badge?.text = queue.size.toString()

        // Couleur bulle selon mode
        bubbleCore?.setBackgroundResource(
            if (modeIndex % 2 == 0) R.drawable.bg_bubble_amber else R.drawable.bg_bubble_teal
        )

        // Bouton droit
        val item = queue.getOrNull(queueIndex)
        when {
            item?.status == StatusIcon.PENDING_PAY -> {
                btnCancel?.text = "PAYER"
                btnCancel?.setBackgroundResource(R.drawable.bg_side_pay)
            }
            modeIndex % 2 == 0 -> {
                btnCancel?.text = "ANNULER"
                btnCancel?.setBackgroundResource(R.drawable.bg_side_cancel)
            }
            else -> {
                btnCancel?.text = "ERREUR"
                btnCancel?.setBackgroundResource(R.drawable.bg_side_cancel)
            }
        }

        // File vide → masquer tout sauf bulle
        val empty = queue.isEmpty()
        btnNext?.visibility = if (empty) View.GONE else View.VISIBLE
        btnCancel?.visibility = if (empty) View.GONE else View.VISIBLE
        btnBack?.visibility = if (empty) View.GONE else View.VISIBLE
        topIcons?.visibility = if (empty) View.GONE else View.VISIBLE
        if (empty) {
            removeCircles()
            opsList?.visibility = View.GONE
            listVisible = false
        }

        if (listVisible) renderOpsList()
    }

    private fun renderOpsList() {
        val body = opsListBody ?: return
        body.removeAllViews()
        val mode = currentMode()
        opsListTitle?.text = if (mode != null) {
            "File ${mode.name} (${queue.size})"
        } else "File"

        queue.forEachIndexed { i, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(4), dp(3), dp(4), dp(3))
                setBackgroundResource(
                    if (i == queueIndex) R.drawable.bg_ops_item_current else R.drawable.bg_ops_item
                )
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.bottomMargin = dp(2) }
            }
            val left = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                text = item.cells.getOrNull(0) ?: ""
                textSize = 9f
                setTextColor(if (i == queueIndex) 0xFFFDE68A.toInt() else 0xFFCBD5E1.toInt())
                maxLines = 1
            }
            val mid = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(18), LinearLayout.LayoutParams.WRAP_CONTENT)
                gravity = Gravity.CENTER
                text = StatusIcon.ICONS.getOrElse(item.status) { "⭕" }
                textSize = 11f
            }
            val right = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                text = item.cells.getOrNull(1) ?: item.cells.getOrNull(item.cells.lastIndex) ?: ""
                textSize = 8f
                setTextColor(if (i == queueIndex) 0xFFFDE68A.toInt() else 0xFF94A3B8.toInt())
                gravity = Gravity.END
                maxLines = 1
            }
            row.addView(left); row.addView(mid); row.addView(right)
            body.addView(row)
        }
    }

    // ─── Step execution ──────────────────────────────────

    private fun performStep() {
        val mode = currentMode() ?: return
        val circle = currentCircle() ?: return
        val service = ClickAccessibilityService.instance

        // Détecteur de temps (1er essai)
        if (config.timingDetector && firstRunTiming) {
            val now = SystemClock.elapsedRealtime()
            if (lastTapTime > 0 && stepIndex < mode.circles.size) {
                mode.circles[stepIndex].delay = ((now - lastTapTime) / 1000f).coerceIn(0f, 30f)
            }
            lastTapTime = now
        }

        val params = circleParams.getOrNull(stepIndex)
        val size = dp(38)
        val tapX = (params?.x ?: 200) + size / 2f
        val tapY = (params?.y ?: 400) + size / 2f

        when (circle.type) {
            "click" -> service?.tap(tapX, tapY)
            "copy" -> {
                mappedValue(stepIndex)?.let { v ->
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("bubble", v))
                }
                service?.tap(tapX, tapY)
            }
            "paste" -> {
                val v = mappedValue(stepIndex)
                service?.tap(tapX, tapY)
                if (v != null) handler.postDelayed({ service?.pasteText(v) }, 120)
            }
        }
        vibrate(30)

        val name = circle.name.lowercase()
        val isLast = stepIndex >= mode.circles.size - 1
        if (isLast || name.contains("valider")) {
            markItem(StatusIcon.VALIDATED)
        } else if (name.contains("approuver")) {
            markItem(StatusIcon.PENDING_PAY)
        }

        val delaySec = circle.delay
        stepIndex++
        if (stepIndex >= mode.circles.size) {
            stepIndex = 0
            if (!name.contains("approuver")) autoAdvance()
        }
        updateUI()

        if (delaySec > 0f) startCountdown((delaySec * 1000).toLong())
    }

    private fun mappedValue(circleIdx: Int): String? {
        val mode = currentMode() ?: return null
        val item = queue.getOrNull(queueIndex) ?: return null
        val col = mode.mapping.entries.find { it.value == circleIdx }?.key ?: return null
        return item.cells.getOrNull(col)
    }

    private fun markItem(status: Int) {
        queue.getOrNull(queueIndex)?.status = status
        if (status == StatusIcon.VALIDATED || status == StatusIcon.CANCELLED) {
            scheduleRemove(queueIndex)
        }
    }

    private fun scheduleRemove(idx: Int) {
        handler.postDelayed({
            if (idx in queue.indices) {
                queue.removeAt(idx)
                if (queueIndex >= queue.size) queueIndex = maxOf(0, queue.size - 1)
                if (queueIndex < 0) queueIndex = 0
                stepIndex = 0
                updateUI()
            }
        }, 2000)
    }

    private fun findNextActiveIndex(from: Int): Int {
        if (queue.isEmpty()) return -1
        for (i in 1..queue.size) {
            val idx = (from + i) % queue.size
            val s = queue[idx].status
            if (s != StatusIcon.VALIDATED && s != StatusIcon.CANCELLED) return idx
        }
        return -1
    }

    private fun autoAdvance() {
        val next = findNextActiveIndex(queueIndex)
        if (next >= 0) queueIndex = next
        stepIndex = 0
        updateUI()
    }

    private fun switchMode() {
        if (config.modes.isEmpty()) return
        modeIndex = (modeIndex + 1) % config.modes.size
        stepIndex = 0
        initQueue()
        removeCircles()
        showCircles()
        if (config.timingDetector) {
            firstRunTiming = false
            BubbleApp.instance.configRepository.save(config)
        }
        updateUI()
    }

    private fun startCountdown(ms: Long) {
        isCountingDown = true
        countdownText?.visibility = View.VISIBLE
        val start = SystemClock.elapsedRealtime()
        fun tick() {
            val left = ms - (SystemClock.elapsedRealtime() - start)
            if (left <= 0) {
                isCountingDown = false
                countdownText?.visibility = View.GONE
                return
            }
            countdownText?.text = String.format("%.1f", left / 1000f)
            handler.postDelayed({ tick() }, 50)
        }
        tick()
    }

    private fun vibrate(ms: Long) {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION") v.vibrate(ms)
        }
    }

    private fun buildNotification(): Notification {
        val channelId = "bubble_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(channelId, getString(R.string.notification_channel), NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.floatingbubble.app.STOP"
        const val ACTION_RELOAD = "com.floatingbubble.app.RELOAD"
        private const val NOTIFICATION_ID = 42

        fun start(ctx: Context) {
            val i = Intent(ctx, FloatingBubbleService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(i)
            else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, FloatingBubbleService::class.java).setAction(ACTION_STOP))
        }

        fun reload(ctx: Context) {
            ctx.startService(Intent(ctx, FloatingBubbleService::class.java).setAction(ACTION_RELOAD))
        }
    }
}
