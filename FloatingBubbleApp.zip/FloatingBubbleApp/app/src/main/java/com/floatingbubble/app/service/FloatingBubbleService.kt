package com.floatingbubble.app.service

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.*
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.net.Uri
import android.os.*
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.floatingbubble.app.BubbleApp
import com.floatingbubble.app.R
import com.floatingbubble.app.data.*
import com.floatingbubble.app.ui.MainActivity

class FloatingBubbleService : Service() {

    private lateinit var windowManager: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var config: AppConfig = AppConfig()

    private var groupView: View? = null
    private var groupParams: WindowManager.LayoutParams? = null
    /** Liste en fenêtre séparée pour ne PAS déplacer la bulle */
    private var listView: View? = null
    private var listParams: WindowManager.LayoutParams? = null

    private val circleViews = mutableListOf<View>()
    private val circleParams = mutableListOf<WindowManager.LayoutParams>()

    private var modeIndex = 0
    private var stepIndex = 0
    private var queueIndex = 0
    private var queue = mutableListOf<QueueItem>()
    private var isCountingDown = false
    private var circlesVisible = true
    private var listVisible = false
    private var firstRunTiming = true
    private var lastTapTime = 0L
    private var lastClickTime = 0L

    private var bubbleLabel: TextView? = null
    private var bubbleCore: View? = null
    private var badge: TextView? = null
    private var eyeBtn: TextView? = null
    private var countdownText: TextView? = null
    private var btnNext: TextView? = null
    private var btnCancel: TextView? = null
    private var btnBack: TextView? = null
    private var opsListTitle: TextView? = null
    private var opsListBody: LinearLayout? = null
    private var mainBubble: View? = null

    private val circleColors = intArrayOf(
        R.drawable.bg_circle_0, R.drawable.bg_circle_1, R.drawable.bg_circle_2,
        R.drawable.bg_circle_3, R.drawable.bg_circle_4, R.drawable.bg_circle_5,
        R.drawable.bg_circle_6, R.drawable.bg_circle_7
    )

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        config = BubbleApp.instance.configRepository.load()
        startForeground(NOTIFICATION_ID, buildNotification())
        initQueue()
        showGroup()
        showCircles()
        updateUI()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_RELOAD -> {
                config = BubbleApp.instance.configRepository.load()
                modeIndex = 0; stepIndex = 0
                initQueue()
                removeCircles(); showCircles()
                hideListWindow()
                updateUI()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        hideListWindow()
        removeCircles()
        removeGroup()
        super.onDestroy()
    }

    private fun initQueue() {
        val mode = currentMode()
        queue = if (mode != null && mode.rows.isNotEmpty()) {
            mode.rows.map { QueueItem(it.toList(), StatusIcon.IN_PROGRESS) }.toMutableList()
        } else mutableListOf()
        queueIndex = 0
    }

    private fun currentMode(): ModeConfig? = config.modes.getOrNull(modeIndex)
    private fun currentCircle(): CircleConfig? = currentMode()?.circles?.getOrNull(stepIndex)
    private fun hasQueue(): Boolean = queue.isNotEmpty()
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun baseParams(x: Int, y: Int, w: Int = WindowManager.LayoutParams.WRAP_CONTENT,
                           h: Int = WindowManager.LayoutParams.WRAP_CONTENT) =
        WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x; this.y = y
        }

    // ─── Groupe (sans la liste dedans pour éviter le décalage) ──

    private fun showGroup() {
        if (groupView != null) return
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_bubble_group, null)
        groupView = view

        bubbleLabel = view.findViewById(R.id.bubbleLabel)
        bubbleCore = view.findViewById(R.id.bubbleCore)
        badge = view.findViewById(R.id.badge)
        eyeBtn = view.findViewById(R.id.eyeBtn)
        countdownText = view.findViewById(R.id.countdownText)
        btnNext = view.findViewById(R.id.btnNext)
        btnCancel = view.findViewById(R.id.btnCancel)
        btnBack = view.findViewById(R.id.btnBack)
        mainBubble = view.findViewById(R.id.mainBubble)

        // Masquer la liste intégrée — on utilise une fenêtre séparée
        view.findViewById<View>(R.id.opsList)?.visibility = View.GONE

        val dm = resources.displayMetrics
        val params = baseParams(dm.widthPixels - dp(160), dm.heightPixels - dp(240))
        groupParams = params
        windowManager.addView(view, params)

        setupGroupDragAndTap()
        setupButtons()
    }

    private fun setupGroupDragAndTap() {
        val bubble = mainBubble ?: return
        val params = groupParams ?: return
        var iX = 0; var iY = 0; var tX = 0f; var tY = 0f
        var moved = false; var longFired = false
        // Appui long 2s → fermer la bulle
        val longRunnable = Runnable {
            if (!moved) {
                longFired = true
                vibrate(80)
                stopSelf()
            }
        }

        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    iX = params.x; iY = params.y
                    tX = e.rawX; tY = e.rawY
                    moved = false; longFired = false
                    handler.postDelayed(longRunnable, 2000)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tX).toInt()
                    val dy = (e.rawY - tY).toInt()
                    if (kotlin.math.abs(dx) > 12 || kotlin.math.abs(dy) > 12) {
                        moved = true
                        handler.removeCallbacks(longRunnable)
                    }
                    if (moved) {
                        params.x = iX + dx
                        params.y = iY + dy
                        try { windowManager.updateViewLayout(groupView, params) } catch (_: Exception) {}
                        // Repositionner la liste au-dessus si ouverte
                        if (listVisible) positionListAboveBubble()
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longRunnable)
                    if (!moved && !longFired && !isCountingDown) {
                        val now = SystemClock.elapsedRealtime()
                        // Double-tap rapide → change de mode
                        if (now - lastClickTime < 280) {
                            switchMode()
                            lastClickTime = 0
                        } else {
                            lastClickTime = now
                            performStep()
                        }
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun setupButtons() {
        btnNext?.setOnClickListener {
            if (!hasQueue()) return@setOnClickListener
            val next = findNextActiveIndex(queueIndex)
            if (next >= 0) {
                queueIndex = next; stepIndex = 0
                updateUI(); vibrate(25)
            }
        }
        btnCancel?.setOnClickListener {
            if (!hasQueue()) return@setOnClickListener
            val item = queue.getOrNull(queueIndex) ?: return@setOnClickListener
            val processed = queueIndex
            item.status = if (item.status == StatusIcon.PENDING_PAY) StatusIcon.VALIDATED else StatusIcon.CANCELLED
            scheduleRemove(processed)
            autoAdvance()
            vibrate(40)
            updateUI()
        }
        btnBack?.setOnClickListener {
            val mode = currentMode() ?: return@setOnClickListener
            if (mode.circles.isEmpty()) return@setOnClickListener
            stepIndex = (stepIndex - 1 + mode.circles.size) % mode.circles.size
            updateUI()
        }
        eyeBtn?.setOnClickListener {
            circlesVisible = !circlesVisible
            circleViews.forEach { it.visibility = if (circlesVisible) View.VISIBLE else View.GONE }
            eyeBtn?.text = if (circlesVisible) "👁" else "👁‍🗨"
        }
        badge?.setOnClickListener {
            if (!hasQueue()) return@setOnClickListener
            listVisible = !listVisible
            if (listVisible) showListWindow() else hideListWindow()
        }
    }

    // ─── Liste en fenêtre séparée (ne bouge pas la bulle) ──

    private fun showListWindow() {
        if (listView != null) {
            listView?.visibility = View.VISIBLE
            positionListAboveBubble()
            renderOpsList()
            return
        }
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_ops_list, null)
        listView = view
        opsListTitle = view.findViewById(R.id.opsListTitle)
        opsListBody = view.findViewById(R.id.opsListBody)
        val params = baseParams(0, 0)
        listParams = params
        windowManager.addView(view, params)
        positionListAboveBubble()
        renderOpsList()
    }

    private fun hideListWindow() {
        listView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        listView = null
        listParams = null
        listVisible = false
    }

    private fun positionListAboveBubble() {
        val gp = groupParams ?: return
        val lp = listParams ?: return
        val lv = listView ?: return
        // Mesurer
        lv.measure(
            View.MeasureSpec.makeMeasureSpec(dp(140), View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val listH = lv.measuredHeight
        val listW = dp(140)
        // Centré horizontalement sur le groupe, au-dessus
        lp.x = gp.x + (groupView?.width ?: dp(140)) / 2 - listW / 2
        lp.y = gp.y - listH - dp(8)
        if (lp.y < 0) lp.y = 0
        try { windowManager.updateViewLayout(lv, lp) } catch (_: Exception) {}
    }

    private fun removeGroup() {
        groupView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        groupView = null
    }

    // ─── Cercles ─────────────────────────────────────────

    private fun showCircles() {
        val mode = currentMode() ?: return
        val dm = resources.displayMetrics
        mode.circles.forEachIndexed { i, circle ->
            val saved = mode.circlePositions.getOrNull(i)
            val x = saved?.x?.toInt() ?: (dp(24) + (i % 3) * dp(50))
            val y = saved?.y?.toInt() ?: (dm.heightPixels / 3 + (i / 3) * dp(50))
            addCircle(i, circle, x, y)
        }
    }

    private fun addCircle(index: Int, circle: CircleConfig, x: Int, y: Int) {
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_circle, null)
        val size = dp(38)
        view.findViewById<View>(R.id.circleBg)
            .setBackgroundResource(circleColors[index % circleColors.size])
        view.findViewById<TextView>(R.id.circleLabel).text =
            circle.name.let { if (it.length > 7) it.take(6) + "…" else it }

        val params = baseParams(x, y, size, size)
        windowManager.addView(view, params)
        circleViews.add(view)
        circleParams.add(params)

        var iX = 0; var iY = 0; var tX = 0f; var tY = 0f
        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    iX = params.x; iY = params.y; tX = e.rawX; tY = e.rawY; true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = iX + (e.rawX - tX).toInt()
                    params.y = iY + (e.rawY - tY).toInt()
                    try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    currentMode()?.let { mode ->
                        while (mode.circlePositions.size <= index) mode.circlePositions.add(Position())
                        mode.circlePositions[index] = Position(params.x.toFloat(), params.y.toFloat())
                        BubbleApp.instance.configRepository.save(config)
                    }
                    true
                }
                else -> false
            }
        }
        if (!circlesVisible) view.visibility = View.GONE
    }

    private fun removeCircles() {
        circleViews.forEach { try { windowManager.removeView(it) } catch (_: Exception) {} }
        circleViews.clear()
        circleParams.clear()
    }

    private fun showRipple(screenX: Float, screenY: Float) {
        val size = dp(48)
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_ripple, null)
        val params = baseParams((screenX - size / 2f).toInt(), (screenY - size / 2f).toInt(), size, size)
        params.flags = params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { windowManager.addView(view, params) } catch (_: Exception) { return }
        view.alpha = 0.9f; view.scaleX = 0.3f; view.scaleY = 0.3f
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 400
            interpolator = DecelerateInterpolator()
            addUpdateListener { a ->
                val t = a.animatedFraction
                view.scaleX = 0.3f + t * 1.7f
                view.scaleY = 0.3f + t * 1.7f
                view.alpha = 0.9f * (1f - t)
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    try { windowManager.removeView(view) } catch (_: Exception) {}
                }
            })
            start()
        }
        circleViews.getOrNull(stepIndex)?.let { cv ->
            cv.animate().scaleX(1.2f).scaleY(1.2f).setDuration(120)
                .withEndAction { cv.animate().scaleX(1f).scaleY(1f).setDuration(120).start() }.start()
        }
    }

    private fun updateUI() {
        val circle = currentCircle()
        bubbleLabel?.text = circle?.name ?: "—"
        badge?.text = queue.size.toString()
        bubbleCore?.setBackgroundResource(
            if (modeIndex % 2 == 0) R.drawable.bg_bubble_amber else R.drawable.bg_bubble_teal
        )
        val item = queue.getOrNull(queueIndex)
        when {
            item?.status == StatusIcon.PENDING_PAY -> {
                btnCancel?.text = "PAYER"
                btnCancel?.setBackgroundResource(R.drawable.bg_side_pay)
            }
            modeIndex % 2 == 0 -> {
                btnCancel?.text = "ANNULER"
                btnCancel?.setBackgroundResource(R.drawable.bg_side_cancel)
            }
            else -> {
                btnCancel?.text = "ERREUR"
                btnCancel?.setBackgroundResource(R.drawable.bg_side_cancel)
            }
        }
        val empty = !hasQueue()
        btnNext?.visibility = if (empty) View.GONE else View.VISIBLE
        btnCancel?.visibility = if (empty) View.GONE else View.VISIBLE
        badge?.visibility = if (empty) View.INVISIBLE else View.VISIBLE
        if (empty) hideListWindow()
        if (listVisible) renderOpsList()
    }

    private fun renderOpsList() {
        val body = opsListBody ?: return
        body.removeAllViews()
        val mode = currentMode()
        opsListTitle?.text = if (mode != null) "File ${mode.name} (${queue.size})" else "File"
        queue.forEachIndexed { i, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(4), dp(3), dp(4), dp(3))
                setBackgroundResource(if (i == queueIndex) R.drawable.bg_ops_item_current else R.drawable.bg_ops_item)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.bottomMargin = dp(2) }
            }
            val c = if (i == queueIndex) 0xFFFDE68A.toInt() else 0xFFCBD5E1.toInt()
            fun cell(t: String, w: Float, s: Float, g: Int = Gravity.START) =
                TextView(this).apply {
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, w)
                    text = t; textSize = s; setTextColor(c); gravity = g; maxLines = 1
                }
            row.addView(cell(item.cells.getOrNull(0) ?: "", 1f, 9f))
            row.addView(cell(StatusIcon.ICONS.getOrElse(item.status) { "⭕" }, 0.3f, 11f, Gravity.CENTER))
            row.addView(cell(item.cells.getOrNull(1) ?: item.cells.lastOrNull() ?: "", 1f, 8f, Gravity.END))
            body.addView(row)
        }
        positionListAboveBubble()
    }

    // ─── Étape : vibration + clic simultanés, puis décompte si activé ──

    private fun performStep() {
        val mode = currentMode() ?: return
        if (mode.circles.isEmpty()) return
        val circle = currentCircle() ?: return
        val service = ClickAccessibilityService.instance

        // Vibration IMMÉDIATE (avec le clic / animation)
        vibrate(30)

        if (config.timingDetector && firstRunTiming) {
            val now = SystemClock.elapsedRealtime()
            if (lastTapTime > 0 && stepIndex < mode.circles.size) {
                mode.circles[stepIndex].delay = ((now - lastTapTime) / 1000f).coerceIn(0f, 30f)
            }
            lastTapTime = now
        }

        val params = circleParams.getOrNull(stepIndex)
        val size = dp(38)
        val tapX = (params?.x ?: 200) + size / 2f
        val tapY = (params?.y ?: 400) + size / 2f

        // Animation + action réelle en même temps
        showRipple(tapX, tapY)
        executeCircleAction(circle, tapX, tapY, service)

        val name = circle.name.lowercase()
        val isLast = stepIndex >= mode.circles.size - 1
        if (hasQueue()) {
            if (isLast || name.contains("valider")) markItem(StatusIcon.VALIDATED)
            else if (name.contains("approuver")) markItem(StatusIcon.PENDING_PAY)
        }

        val delaySec = circle.delay
        stepIndex++
        if (stepIndex >= mode.circles.size) {
            stepIndex = 0
            if (hasQueue() && !name.contains("approuver")) autoAdvance()
            if (config.timingDetector && firstRunTiming) {
                firstRunTiming = false
                BubbleApp.instance.configRepository.save(config)
            }
        }
        updateUI()

        // Décompte seulement si option activée ET délai > 0
        if (config.countdownEnabled && delaySec > 0f) {
            startCountdown((delaySec * 1000).toLong())
        }
    }

    private fun executeCircleAction(circle: CircleConfig, x: Float, y: Float, service: ClickAccessibilityService?) {
        when (circle.type) {
            "click" -> service?.tap(x, y)
            "copy" -> {
                mappedValue(stepIndex)?.let { putClipboard(it) }
                service?.tap(x, y)
            }
            "paste" -> {
                val v = mappedValue(stepIndex)
                service?.tap(x, y)
                if (v != null) handler.postDelayed({ service?.pasteText(v) }, 150)
            }
            "click_copy" -> {
                service?.tap(x, y)
                mappedValue(stepIndex)?.let { putClipboard(it) }
            }
            "click_paste" -> {
                service?.tap(x, y)
                val v = mappedValue(stepIndex) ?: circle.payload
                if (v.isNotBlank()) handler.postDelayed({ service?.pasteText(v) }, 150)
            }
            "launch_app" -> {
                val pkg = circle.payload
                if (pkg.isNotBlank()) {
                    packageManager.getLaunchIntentForPackage(pkg)?.let {
                        it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(it)
                    }
                }
            }
            "command" -> {
                // Intent générique ou action
                val payload = circle.payload
                if (payload.startsWith("intent:") || payload.contains("://")) {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(payload)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Exception) {}
                } else if (payload.isNotBlank()) {
                    try {
                        Runtime.getRuntime().exec(arrayOf("sh", "-c", payload))
                    } catch (_: Exception) {}
                }
            }
            "ussd" -> {
                var code = circle.payload.ifBlank { mappedValue(stepIndex) ?: "" }
                if (code.isNotBlank()) {
                    if (!code.endsWith("#")) code = "$code"
                    val ussd = "tel:" + Uri.encode(code)
                    try {
                        startActivity(Intent(Intent.ACTION_CALL, Uri.parse(ussd)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Exception) {
                        try {
                            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse(ussd)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } catch (_: Exception) {}
                    }
                }
            }
            else -> service?.tap(x, y)
        }
    }

    private fun putClipboard(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("bubble", text))
    }

    private fun mappedValue(circleIdx: Int): String? {
        if (!hasQueue()) return null
        val mode = currentMode() ?: return null
        val item = queue.getOrNull(queueIndex) ?: return null
        val col = mode.mapping.entries.find { it.value == circleIdx }?.key ?: return null
        return item.cells.getOrNull(col)
    }

    private fun markItem(status: Int) {
        queue.getOrNull(queueIndex)?.status = status
        if (status == StatusIcon.VALIDATED || status == StatusIcon.CANCELLED) scheduleRemove(queueIndex)
    }

    private fun scheduleRemove(idx: Int) {
        handler.postDelayed({
            if (idx in queue.indices) {
                queue.removeAt(idx)
                if (queueIndex >= queue.size) queueIndex = maxOf(0, queue.size - 1)
                stepIndex = 0
                updateUI()
            }
        }, 2000)
    }

    private fun findNextActiveIndex(from: Int): Int {
        if (queue.isEmpty()) return -1
        for (i in 1..queue.size) {
            val idx = (from + i) % queue.size
            val s = queue[idx].status
            if (s != StatusIcon.VALIDATED && s != StatusIcon.CANCELLED) return idx
        }
        return -1
    }

    private fun autoAdvance() {
        val next = findNextActiveIndex(queueIndex)
        if (next >= 0) queueIndex = next
        stepIndex = 0
        updateUI()
    }

    private fun switchMode() {
        if (config.modes.isEmpty()) return
        modeIndex = (modeIndex + 1) % config.modes.size
        stepIndex = 0
        initQueue()
        removeCircles(); showCircles()
        hideListWindow()
        updateUI()
        vibrate(50)
    }

    private fun startCountdown(ms: Long) {
        if (ms <= 0L || !config.countdownEnabled) return
        isCountingDown = true
        countdownText?.visibility = View.VISIBLE
        val start = SystemClock.elapsedRealtime()
        fun tick() {
            val left = ms - (SystemClock.elapsedRealtime() - start)
            if (left <= 0) {
                isCountingDown = false
                countdownText?.visibility = View.GONE
                countdownText?.text = ""
                return
            }
            countdownText?.text = String.format("%.1f", left / 1000f)
            handler.postDelayed({ tick() }, 50)
        }
        tick()
    }

    private fun vibrate(ms: Long) {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION") v.vibrate(ms)
        }
    }

    private fun buildNotification(): Notification {
        val channelId = "bubble_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(channelId, getString(R.string.notification_channel), NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.floatingbubble.app.STOP"
        const val ACTION_RELOAD = "com.floatingbubble.app.RELOAD"
        private const val NOTIFICATION_ID = 42
        fun start(ctx: Context) {
            val i = Intent(ctx, FloatingBubbleService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(i) else ctx.startService(i)
        }
        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, FloatingBubbleService::class.java).setAction(ACTION_STOP))
        }
        fun reload(ctx: Context) {
            ctx.startService(Intent(ctx, FloatingBubbleService::class.java).setAction(ACTION_RELOAD))
        }
    }
}
