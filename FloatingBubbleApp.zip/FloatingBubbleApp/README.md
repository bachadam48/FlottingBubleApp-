# Bulle Flottante — Application Android

Application Android de bulle flottante pour automatiser des séquences de clics, copies et collages sur l’écran.

## Fonctionnalités

- **Bulle flottante** superposée aux autres applications
- **Plusieurs modes** (ex. Dépôt / Retrait), chacun avec ses petits cercles
- **Types de cercles** : clic bouton, copier presse-papiers, focus + coller
- **Délais** entre clics (décompte affiché, bulle désactivée pendant l’attente)
- **Détecteur de temps** : mesure les intervalles au premier essai réel
- **Tableaux de données par mode** avec mapping colonnes → cercles
- **File d’attente** avec statuts ⭕ ✅ ☑️ ❌
- **Service d’accessibilité** pour simuler les appuis
- Import / export de la configuration en **JSON**

## Prérequis

- Android Studio Hedgehog (2023.1.1) ou plus récent
- JDK 17
- Android SDK 34
- Appareil ou émulateur **Android 8.0+** (API 26)

## Permissions à accorder

1. **Affichage par-dessus les autres apps** (SYSTEM_ALERT_WINDOW)
2. **Service d’accessibilité** (simulation de clics)

L’écran d’accueil de l’app indique l’état de chaque permission et permet de les activer.

## Compilation locale

```bash
# Depuis la racine du projet
./gradlew assembleDebug

# APK généré :
# app/build/outputs/apk/debug/app-debug.apk
```

Pour installer sur un appareil connecté :

```bash
./gradlew installDebug
```

## Configuration

1. Ouvrez **Configuration** dans l’app
2. Activez / désactivez la bulle et le détecteur de temps
3. Pour une config avancée (modes, cercles, mapping, tableaux) :
   - Utilisez le fichier web `bubble_settings_ui.html`
   - Exportez le JSON
   - Copiez-le dans le presse-papiers de l’appareil
   - Dans l’app : **Importer config JSON**

## Structure du projet

```
FloatingBubbleApp/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/floatingbubble/app/
│       │   ├── BubbleApp.kt
│       │   ├── data/          # Modèles + ConfigRepository
│       │   ├── service/       # FloatingBubbleService, ClickAccessibilityService
│       │   ├── ui/            # MainActivity, SettingsActivity
│       │   └── util/          # PermissionHelper
│       └── res/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── .github/workflows/android-build.yml
```

## GitHub Actions

Le workflow `.github/workflows/android-build.yml` :

1. Checkout du dépôt
2. Setup JDK 17
3. Build `assembleDebug`
4. Upload de l’APK en artifact

Déclenché sur `push` et `pull_request` vers `main` / `master`.

## Licence

Projet fourni à titre d’exemple / mockup fonctionnel.
